create function st_linecrossingdirection(line1 geometry, line2 geometry) returns integer
    immutable
    parallel safe
    language sql
as
$$
SELECT CASE WHEN NOT $1 OPERATOR(public.&&) $2 THEN 0 ELSE public._ST_LineCrossingDirection($1,$2) END
$$;

alter function st_linecrossingdirection(geometry, geometry) owner to postgres;

