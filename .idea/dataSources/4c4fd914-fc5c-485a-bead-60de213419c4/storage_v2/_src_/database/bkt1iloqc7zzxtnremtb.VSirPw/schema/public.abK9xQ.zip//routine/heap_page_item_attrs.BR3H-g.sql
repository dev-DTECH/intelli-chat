create function heap_page_item_attrs(page bytea, rel_oid regclass, do_detoast boolean, OUT lp smallint, OUT lp_off smallint, OUT lp_flags smallint, OUT lp_len smallint, OUT t_xmin xid, OUT t_xmax xid, OUT t_field3 integer, OUT t_ctid tid, OUT t_infomask2 integer, OUT t_infomask integer, OUT t_hoff smallint, OUT t_bits text, OUT t_oid oid, OUT t_attrs bytea[]) returns SETOF record
    parallel safe
    language sql
as
$$
SELECT lp,
       lp_off,
       lp_flags,
       lp_len,
       t_xmin,
       t_xmax,
       t_field3,
       t_ctid,
       t_infomask2,
       t_infomask,
       t_hoff,
       t_bits,
       t_oid,
       tuple_data_split(
         rel_oid,
         t_data,
         t_infomask,
         t_infomask2,
         t_bits,
         do_detoast)
         AS t_attrs
  FROM heap_page_items(page);
$$;

alter function heap_page_item_attrs(bytea, regclass, boolean, out smallint, out smallint, out smallint, out smallint, out xid, out xid, out integer, out tid, out integer, out integer, out smallint, out text, out oid, out bytea[]) owner to postgres;

