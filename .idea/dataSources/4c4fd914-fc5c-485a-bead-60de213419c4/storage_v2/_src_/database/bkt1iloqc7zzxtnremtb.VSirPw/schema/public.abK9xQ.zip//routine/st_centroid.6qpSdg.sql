create function st_centroid(text) returns geometry
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT public.ST_Centroid($1::public.geometry);
$$;

alter function st_centroid(text) owner to postgres;

