create view pg_buffercache
            (bufferid, relfilenode, reltablespace, reldatabase, relforknumber, relblocknumber, isdirty, usagecount,
             pinning_backends)
as
SELECT p.bufferid,
       p.relfilenode,
       p.reltablespace,
       p.reldatabase,
       p.relforknumber,
       p.relblocknumber,
       p.isdirty,
       p.usagecount,
       p.pinning_backends
FROM pg_buffercache_pages() p(bufferid integer, relfilenode oid, reltablespace oid, reldatabase oid,
                              relforknumber smallint, relblocknumber bigint, isdirty boolean, usagecount smallint,
                              pinning_backends integer);

alter table pg_buffercache
    owner to postgres;

grant select on pg_buffercache to pg_monitor;

