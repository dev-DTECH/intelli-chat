create function heap_page_item_attrs(page bytea, rel_oid regclass, OUT lp smallint, OUT lp_off smallint, OUT lp_flags smallint, OUT lp_len smallint, OUT t_xmin xid, OUT t_xmax xid, OUT t_field3 integer, OUT t_ctid tid, OUT t_infomask2 integer, OUT t_infomask integer, OUT t_hoff smallint, OUT t_bits text, OUT t_oid oid, OUT t_attrs bytea[]) returns SETOF record
    parallel safe
    language sql
as
$$
SELECT * from heap_page_item_attrs(page, rel_oid, false);
$$;

alter function heap_page_item_attrs(bytea, regclass, out smallint, out smallint, out smallint, out smallint, out xid, out xid, out integer, out tid, out integer, out integer, out smallint, out text, out oid, out bytea[]) owner to postgres;

