create function st_multipointfromwkb(bytea) returns geometry
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$
SELECT CASE WHEN public.geometrytype(public.ST_GeomFromWKB($1)) = 'MULTIPOINT'
	THEN public.ST_GeomFromWKB($1)
	ELSE NULL END

$$;

alter function st_multipointfromwkb(bytea) owner to postgres;

